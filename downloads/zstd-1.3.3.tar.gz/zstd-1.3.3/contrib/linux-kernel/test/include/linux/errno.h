#ifndef LINUX_ERRNO_H_
#define LINUX_ERRNO_H_

#define EINVAL 22

#endif // LINUX_ERRNO_H_
